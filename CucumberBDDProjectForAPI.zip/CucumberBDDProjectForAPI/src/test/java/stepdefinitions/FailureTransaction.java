package stepdefinitions;

import io.cucumber.java.en.Given;

public class FailureTransaction {
    @Given("The user has invalid {string} card no {string} issued from {string} and account balance {string} and doing transaction from {string}")
    public void theUserHasInvalidCardNoIssuedFromAndAccountBalanceAndDoingTransactionFrom(String arg0, String arg1, String arg2, String arg3, String arg4) {

    }
}
