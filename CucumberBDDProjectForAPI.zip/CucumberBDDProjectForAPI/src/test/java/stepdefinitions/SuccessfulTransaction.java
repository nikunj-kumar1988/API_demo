package stepdefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.restassured.RestAssured;

import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.json.simple.JSONObject;
import org.junit.Assert;

public class SuccessfulTransaction {

    private static final String API_SECRET_KEY = "1234541789741";
    private static final String BASE_URL = "https://xyz.com";

    private static Response response;
    private static String jsonString;
    private static String cardStatus;
    private static String amountInATM;

    @Given("The user has valid {string} and {string} card no {string} and pin {string} and issued from {string} and account balance {string} and doing transaction from {string}")
    public void theUserHasValidAndCardNoAndPinAndIssuedFromAndAccountBalanceAndDoingTransactionFrom
            (String cardValid, String cardType, String cardNo, String pin, String issuedFrom, String accountBalance, String transactionFrom)
    {
        // Initiatlize the BASE_URI
        RestAssured.baseURI = BASE_URL;

        // Create a request object
        RequestSpecification request = RestAssured.given();

        // Adding header into request object
        request.header("Authorization", API_SECRET_KEY)
                .header("Content-Type", "application/json");

        // Prepare request body
        JSONObject requestParams = new JSONObject();
        requestParams.put("FirstName", "Nikunj");
        requestParams.put("LastName", "Kumar");
        requestParams.put("Email",  "xyz@gmail.com");
        requestParams.put("PhoneNo",  "123456789");
        requestParams.put("CardValid",  cardValid);
        requestParams.put("CardType", cardType);
        requestParams.put("CardNo", cardNo);
        requestParams.put("PIN", pin);
        requestParams.put("IssuedFromCountry",  issuedFrom);
        requestParams.put("AccountBalance",  accountBalance);
        requestParams.put("TransactionFromCountry",  transactionFrom);

        request.body(requestParams.toJSONString());

        // Post the request to the server and get the reponse
        Response response = request.post("/path to endpoint");

        // Get the status code
        int statusCode = response.getStatusCode();
        Assert.assertEquals(201, statusCode);

        // get the success code and verify
        String successCode = response.jsonPath().get("SuccessCode");
        Assert.assertEquals( "Correct Success code was returned", "SUCCESS", successCode);

        // get the card status
        cardStatus =  response.jsonPath().get("CardStatus");
    }

    @And("ATM machine contains {string}")
    public void atmMachineContains(String atmAmountAvailability) {
        // Initiatlize the BASE_URI
        RestAssured.baseURI = BASE_URL;

        // Create a request object
        RequestSpecification request = RestAssured.given();

        // Adding header into request object
        request.header("Authorization", API_SECRET_KEY)
                .header("Content-Type", "application/json");

        // Prepare request body
        JSONObject requestParams = new JSONObject();
        requestParams.put("CardStatus", cardStatus);
        request.body(requestParams.toJSONString());

        // get the request to the server and get the reponse
        Response response = request.get("/path to endpoint which check amount in ATM machine");

        // Get the status code
        int statusCode = response.getStatusCode();
        Assert.assertEquals(200, statusCode);

        // get the success code and verify
        String successCode = response.jsonPath().get("SuccessCode");
        Assert.assertEquals( "Correct Success code was returned", "SUCCESS", successCode);

        // get the card status
        amountInATM =  response.jsonPath().get("AmountInATM");
    }





    @Given("The user has valid {string} card no {string} issued from {string} and account balance {string} and doing transaction from {string}")
    public void theUserHasValidCardNoIssuedFromAndAccountBalanceAndDoingTransactionFrom(
            String cardType, String cardNo, String issuedFrom, String accountBalance, String transactionFrom)
    {
        // Initiatlize the BASE_URI
        RestAssured.baseURI = BASE_URL;

        // Create a request object
        RequestSpecification request = RestAssured.given();

        // Adding header into request object
        request.header("Authorization", API_SECRET_KEY)
                .header("Content-Type", "application/json");

        // Prepare request body
        JSONObject requestParams = new JSONObject();
        requestParams.put("FirstName", "Nikunj");
        requestParams.put("LastName", "Kumar");
        requestParams.put("Email",  "xyz@gmail.com");
        requestParams.put("PhoneNo",  "123456789");
        requestParams.put("CardType", cardType);
        requestParams.put("CardNo", cardNo);
        requestParams.put("IssuedFromCountry",  issuedFrom);
        requestParams.put("AccountBalance",  accountBalance);
        requestParams.put("TransactionFromCountry",  transactionFrom);

        request.body(requestParams.toJSONString());

        // Post the request to the server and get the reponse
        Response response = request.post("/path to endpoint");

        // Get the status code
        int statusCode = response.getStatusCode();
        Assert.assertEquals(201, statusCode);

        // get the success code and verify
        String successCode = response.jsonPath().get("SuccessCode");
        Assert.assertEquals( "Correct Success code was returned", "SUCCESS", successCode);

        // Get the card status (valid or Invalid)
        cardStatus = response.jsonPath().get("CardStatus");
    }



    @And("Card is valid {string}")
    public void cardIsValid(String arg0) {

    }

    @And("Pin {string} is valid")
    public void pinIsValid(String arg0) {
        
    }

    @And("the account holder requests {string}")
    public void theAccountHolderRequests(String arg0) {
        
    }

    @Then("ATM should dispense {string}")
    public void atmShouldDispense(String arg0) {
        
    }

    @And("Account account balance should be {string}")
    public void accountAccountBalanceShouldBe(String arg0) {
        
    }

    @And("card should be returned")
    public void cardShouldBeReturned() {

    }


}
